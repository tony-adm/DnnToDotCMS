﻿<section>
  <div class="container">
    
<div class="row">
	<div class="col-md-9" id="ContentPane" runat="server"></div>
  <div class="col-md-3 d-none d-md-block" id="SidePane" runat="server"></div>
  
</div>

    <div class="row Box-Four mt-2">
      <div class="col-md-3" runat="server" id="box1"></div>
      <div class="col-md-3" runat="server" id="box2"></div>
      <div class="col-md-3" runat="server" id="box3"></div>
      <div class="col-md-3" runat="server" id="box4"></div>
    </div>
	   <div class="row Box-Four mt-2">
      <div class="col-md-3" runat="server" id="box1a"></div>
      <div class="col-md-3" runat="server" id="box2a"></div>
      <div class="col-md-3" runat="server" id="box3a"></div>
      <div class="col-md-3" runat="server" id="box4a"></div>
    </div>
    <div class="row Box-Three mt-2">
      <div class="col-md-4" runat="server" id="boxone"></div>
      <div class="col-md-4" runat="server" id="boxtwo"></div>
      <div class="col-md-4" runat="server" id="boxthree"></div>
    </div>
    <div class="row Box-Two mt-2">
      <div class="col-md-6" runat="server" id="boxone1"></div>
      <div class="col-md-6" runat="server" id="boxtwo1"></div>
    </div>
    <div class="row mt-2 Bottom-Pane">
      <div class="col" runat="server" id="bottomPane"></div>
    </div>
  </div>
</section>
