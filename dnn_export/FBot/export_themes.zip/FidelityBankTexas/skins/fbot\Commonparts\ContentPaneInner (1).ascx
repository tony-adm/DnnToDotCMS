﻿
<section>
  <div class="container ContentSection">
    <div class="row">
		
      <div class="col-md-12" id="ContentPane" runat="server"></div>
		
    </div>
	  
	     
      <div class="row">      
        <div class="col-lg" runat="server" id="boxoneA"></div>
        <div class="col-lg" runat="server" id="boxtwoA"></div>
        <div class="col-lg" runat="server" id="boxthreeA"></div>
     
      </div>
	  
    <div class="row">
      <div class="col-md-12" id="ContentPaneFull" runat="server"></div>
    </div>
    <div class="container mt-4 locations">    
      <div class="row">      
        <div class="col" runat="server" id="box1"></div>
        <div class="col" runat="server" id="box2"></div>
        <div class="col" runat="server" id="box3"></div>
        <div class="col" runat="server" id="box4"></div>
      </div>
    </div>
	  <div class="container mt-4 PrivateBank">    
      <div class="row">      
        <div class="col-md" runat="server" id="boxone"></div>
        <div class="col-md" runat="server" id="boxtwo"></div>
        <div class="col-md" runat="server" id="boxthree"></div>
     
      </div>
    </div>
  </div>
</section>
