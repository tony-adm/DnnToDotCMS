﻿<section id="hpcontent">
  <div class="container">
    <div class="row">
      <div class="col-md-12 ContentPane" id="ContentPane" runat="server"></div>
    </div>
  </div>
  <div class="container mt-4 mb-4">
    <div class="row">
      <div class="col-12 Slogan" id="Slogan" runat="server"></div>
    </div>
  </div>
  <div class="container mt-4 mb-4">
    <div class="row">
      <div class="col-12 HR-divider" id="HRdivider" runat="server"></div>
    </div>
  </div>
  <div class="container mt-4 mb-4">
    <div class="row">
      <div class="col-12 help" id="help" runat="server"></div>
    </div>
  </div>
  <div class="container CTA mt-4 mb-4">
    <div class="row">
      <div class="col-lg-6" id="CTA1" runat="server"></div>
      <div class="col-lg-6" id="CTA2" runat="server"></div>
    </div>
    <div class="row">
      <div class="col-lg-6" id="CTA3" runat="server"></div>
      <div class="col-lg-6" id="CTA4" runat="server"></div>
    </div>
  </div>
	
	
	
	
 
	
	<div class="promo">
	
	<div class="container mt-4 px-0">
  <div class="row g-0 d-flex align-items-stretch">
    
    <div class="col-md-6 bg-dark text-white p-5 d-flex flex-column justify-content-center" 
         id="PromoLeft" 
         runat="server">
       </div>
    
    <div class="col-md-6 d-flex" 
         id="PromoRight" 
         runat="server">
       </div>
    
  </div>
</div>

</div>

	
	
	
	
	
	
	
	
<div class="locationBG">	
  <div class="container">
    <div class="row">
      <div class="col-md-6" id="Locationleft" runat="server"></div>
      <div class="col-md-6" id="Locationright" runat="server"></div>
    </div>
  </div>
	</div>
</section>
