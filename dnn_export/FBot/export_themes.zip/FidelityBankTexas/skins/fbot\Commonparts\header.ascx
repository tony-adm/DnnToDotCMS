﻿
  <div class="top-bar-bg">
    <div class="container">
      <div class="row">
        <div class="col-md" id="FDIC" runat="server"> </div>
        <div class="col-md" id="TopRightBar" runat="server"> </div>
      </div>
    </div>
  </div>
  <div id="header"  class="sticky-top">
  
  <div class="container">
    <div class="row">
      <div class="col-xl-10 col-lg-12">
        <div class="container">
          <nav class="navbar navbar-expand-lg navbar-light">
            <dnn:LOGO runat="server" id="dnnLOGO" />
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <dnn:MENU MenuStyle="BootStrapNav" runat="server" CssClass="w-100"></dnn:MENU>
            </div>
            <!--/.nav-collapse --> 
          </nav>
        </div>
      </div>
      <div class="col-xl-2 col-lg-12" id="login" runat="server"> </div>
    </div>
  </div>
</div>
