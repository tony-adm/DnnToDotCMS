// JavaScript Document
// Bootstrap Parent Menu element fix

$('a[href^="https://orderpoint.deluxe.com/personal-checks/home.htm"]').addClass('external');
$('a[href^="https://www.deluxe.com/shopdeluxe/cl/business-checks-banking-products/business-checks/_/N-wha0kw?locid=DOP:top_dept2shopdlx"]').addClass('external');


jQuery(function ($) {

  if ($(window).width() > 993) {


    $('.navbar .dropdown').hover(function () {
      $(this).find('.dropdown-menu').first().stop(true, true).delay(250).slideDown();

    }, function () {
      $(this).find('.dropdown-menu').first().stop(true, true).delay(100).slideUp();

    });

    $('.navbar .dropdown > a').click(function () {
      location.href = this.href;
    });

  }});
    

$(document).ready(function () {
  let scrollTimeout;
  $(window).on('scroll.backToTop', function () {
    clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(function () {
      if ($(window).scrollTop() > 50) {
        $('#back-to-top').fadeIn(200); // Faster fade-in
      } else {
        $('#back-to-top').fadeOut(200); // Faster fade-out
      }
    }, 50); // Reduced from 100ms
  });

  $('#back-to-top').on('click touchstart', function (e) {
    e.preventDefault();
    e.stopPropagation();
    // Removed: $('#back-to-top').tooltip('hide');
    if ('scrollBehavior' in document.documentElement.style) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      $('html, body').animate({ scrollTop: 0 }, 400, 'linear');
    }
  });
});



    
    
    




