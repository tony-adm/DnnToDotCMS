﻿
<footer>
  <div class="socailbg">
    <div class="container">
      <div class="row">
        <div id="SocialMedia" runat="server" class="col-lg-12"></div>
      </div>
    </div>
  </div>
  <div id="FooterContainer" class="Footer-Top-BG">
    <div class="container">
      <div id="FooterRow" class="row">
        <div id="FooterLeft" runat="server" class="col-md-3"></div>
        <div id="FooterLeftCenter" runat="server" class="col-md-3"></div>
        <div id="FooterRightCenter" runat="server" class="col-md-3"></div>
        <div id="FooterRight" runat="server" class="col-md-3"></div>
      </div>
    </div>
  </div>
	<div class="bottomFT"></div>
</footer>
