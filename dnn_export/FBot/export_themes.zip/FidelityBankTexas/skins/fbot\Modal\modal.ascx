﻿<%@ Control Language="C#" AutoEventWireup="true" Inherits="DotNetNuke.UI.Skins.SkinObjectBase" %>

<script type="text/javascript">
    var exUrl = "";
</script>

<!-- start modal-->
<div class="modal fade" id="speedbump" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Notice</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" title="Close"></button>
            </div>
            <div class="modal-body">
                <p>You are now leaving our website.</p>
            </div>
            <div class="modal-footer text-center">
                <button type="button" title="continue" class="btn btn-modal btn-continue" data-bs-dismiss="modal">Continue</button>
                <button type="button" title="go back" class="btn btn-modal btn-close" data-bs-dismiss="modal">Go Back</button>
            </div>
        </div>
    </div>
</div>
<!--end modal-->

<div class="modal fade" id="email" tabindex="-1" role="dialog" aria-labelledby="emailalert">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Disclaimer</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" title="Close"></button>
            </div>
            <div class="modal-body">
                <p>Your privacy is very important to us. We would like to advise you that Internet email is not secure. Please do not submit any information that you consider confidential. We recommend you do not include your social security or account number or other specific identifying information.</p>
            </div>
            <div class="modal-footer">
                <button onclick="window.location = exUrl;" type="button" class="btn btn-primary" data-bs-dismiss="modal">Continue</button>
                <button type="button" data-bs-dismiss="modal" class="btn btn-primary border border-primary">Cancel</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="thirdParty" tabindex="-1" role="dialog" aria-labelledby="thirdParty">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Third Party Website Disclosure</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" title="Close"></button>
            </div>
            <div class="modal-body">
                <p>You are leaving Fidelity Bank of Texas's website and linking to a third party site. Please be advised that you will then link to a website hosted by another party, where you will no longer be subject to, or under the protection of, the privacy and security policies of Fidelity Bank of Texas. We recommend that you review and evaluate the privacy and security policies of the site that you are entering. Fidelity Bank of Texas assumes no liability for the content, information, security, policies or transactions provided by these other sites.</p>
            </div>
            <div class="modal-footer">
                <button onclick="window.location = exUrl;" type="button" class="btn btn-primary" data-bs-dismiss="modal">Continue</button>
                <button type="button" data-bs-dismiss="modal" class="btn btn-primary border border-dark">Cancel</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="thirdPartyNewWindow" tabindex="-1" role="dialog" aria-labelledby="thirdPartyNewWindow">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Third Party Website Disclosure</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" title="Close"></button>
            </div>
            <div class="modal-body">
                <p>You are leaving Fidelity Bank of Texas's website and linking to a third party site. Please be advised that you will then link to a website hosted by another party, where you will no longer be subject to, or under the protection of, the privacy and security policies of Fidelity Bank of Texas. We recommend that you review and evaluate the privacy and security policies of the site that you are entering. Fidelity Bank of Texas assumes no liability for the content, information, security, policies or transactions provided by these other sites.</p>
            </div>
            <div class="modal-footer">
                <button onclick="window.open(exUrl);" type="button" class="btn btn-primary" data-bs-dismiss="modal">Continue</button>
                <button type="button" data-bs-dismiss="modal" class="btn btn-primary border border-dark">Cancel</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="thirdPartyNew" tabindex="-1" role="dialog" aria-labelledby="thirdPartyNew">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Third Party Website Disclosure</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" title="Close"></button>
            </div>
            <div class="modal-body">
                <p>New Disclaimer</p>
            </div>
            <div class="modal-footer">
                <button onclick="window.open(exUrl);" type="button" class="btn btn-primary" data-bs-dismiss="modal">Continue</button>
                <button type="button" data-bs-dismiss="modal" class="btn btn-primary border border-dark">Cancel</button>
            </div>
        </div>
    </div>
</div>
