﻿<%@ Control Language="C#" AutoEventWireup="true" Explicit="True" Inherits="DotNetNuke.UI.Skins.Skin" %>
<%@ Register TagPrefix="dnn" TagName="LOGO" Src="~/Admin/Skins/Logo.ascx" %>
<%@ Register TagPrefix="dnn" TagName="USER" Src="~/Admin/Skins/User.ascx" %>
<%@ Register TagPrefix="dnn" TagName="LOGIN" Src="~/Admin/Skins/Login.ascx" %>
<%@ Register TagPrefix="dnn" TagName="PRIVACY" Src="~/Admin/Skins/Privacy.ascx" %>
<%@ Register TagPrefix="dnn" TagName="TERMS" Src="~/Admin/Skins/Terms.ascx" %>
<%@ Register TagPrefix="dnn" TagName="COPYRIGHT" Src="~/Admin/Skins/Copyright.ascx" %>
<%@ Register TagPrefix="dnn" TagName="JQUERY" Src="~/Admin/Skins/jQuery.ascx" %>
<%@ Register TagPrefix="dnn" TagName="META" Src="~/Admin/Skins/Meta.ascx" %>
<%@ Register TagPrefix="dnn" TagName="MENU" Src="~/DesktopModules/DDRMenu/Menu.ascx" %>
<%@ Register TagPrefix="dnn" Namespace="DotNetNuke.Web.Client.ClientResourceManagement" Assembly="DotNetNuke.Web.Client" %>
<%@ Register TagPrefix="FIS" TagName="Modal" Src="modal/modal.ascx" %>
<%@ Register TagPrefix="dnn" TagName="SEARCH" Src="~/Admin/Skins/search.ascx" %>
<%@ Register TagPrefix="dnn" TagName="LANGUAGE" Src="~/Admin/Skins/Language.ascx" %>
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<link src="<%= SkinPath %>/modal/modal.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <dnn:JQUERY ID="dnnjQuery" runat="server" jQueryHoverIntent="true" />
 <dnn:DnnCssInclude ID="bootStrapCSS" runat="server" FilePath="css/bootstrap.min.css" PathNameAlias="SkinPath" Priority="14" />
    
<link src="<%= SkinPath %>/modal/modal.css">

<a id="skip" href="#maincontent">Skip to main content</a>
	
	
    <a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Click to return on the top page" data-placement="left">Top</a> 
	
	

<!--#include file="CommonParts/header.ascx"--> 
		

<!--#include file="CommonParts/bannerPaneInner.ascx"-->
<a name="maincontent" id="maincontent" tabindex="-1"><span class="visually-hidden">Main</span></a>
  
  <!--#include file="CommonParts/ContentPaneInner.ascx"--> 


<!--#include file="CommonParts/footerPane.ascx"-->

<FIS:Modal id="Modal" runat="server" />
    <script src="<%= SkinPath %>js/custom.js"></script> 


<script src="<%= SkinPath %>/modal/modal.js"></script> 
	
	 <dnn:DnnJsInclude ID="bootstrapJS" runat="server" FilePath="js/bootstrap.bundle.min.js" PathNameAlias="SkinPath" Priority="10" />

