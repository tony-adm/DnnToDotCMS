<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>

<div class="standard_container">
	<div runat="server" id="ContentPane" class="Content" style="display: none;"></div>
</div>

	
<style>
/* Set color variable */
:root {
	--color-var-hex: #000000;
}
	
	sup.reg {
  vertical-align: .8em; /* increase for higher */
  font-size: 0.6em;
  line-height: 0;
}
	
	
</style>
<link rel="stylesheet" href="https://files.marcomcentral.app.pti.com/earlywarning/marcom/products/html/landings/803/css/style.css?v=5.2" />


  
   <!-- Begin Block Hero 5 Code Snippet -->
  <div class="block block-hero five">
    <div class="wrapper">
      <div class="hero">
        <div class="block-hero-intro">
          <div class="logos">
            <img src="https://images.printable.com/imagelibrary/Seller/22953/p1_39875232-4af4-4661-97a8-a38c13d4b91d/images/5280206/src/Fidelity%20-%20Zelle%20-%20Landscape%20Logo_4b2e469d-e4e4-4e7b-876c-9564e7a89d40.png" alt="Fidelity Bank of Texas" height="30" style="max-height: 30px;">
            <img src="https://images.printable.com/imagelibrary/Seller/3374/EarlyWarningHTMLImages_12062017133825_333/images/src/logo_zelle_purple_wPipe_30h.png" alt="Zelle Logo" width="102" height="30" style="max-height: 30px;">
          </div>
          <div class="heading">
            <h1 class="heading-h1">Send and receive money with Zelle<sup class="reg">&reg;</sup> in minutes.<sup>*</sup></h1>
          </div>
          <div class="block-txt">
            <p>You already have access to Zelle<sup class="reg">&reg;</sup> in  the FBOT Mobile App.</p>
          </div>
          <div class="badges">
            <div class="badge-btn apple">
              <a class="external" href="https://urldefense.com/v3/__https://apps.apple.com/us/app/fbot-mobile/id1244150751__;!!AI5hVGByxkJIiw!jLbICTT_xI4Tgc5R8fBieBTZSun_aA4Zvit-1sauJsmRQMzH07ObzcpROcbx_63w9YOXGY9LlHl1jjMgSSvIuQ$" target="_blank"><img src="https://images.printable.com/imagelibrary/Seller/3374/EWSDGTLLandingAssets_06092023085534_142/images/src/badge-apple.png" alt="Download on the App Store button" width="219" height="73"></a>
            </div>
            <div class="badge-btn google">
              <a class="external" href="https://urldefense.com/v3/__https://play.google.com/store/apps/details?id=com.mfoundry.mb.android.mb_111905340&amp;hl=en_US&amp;pli=1__;!!AI5hVGByxkJIiw!jLbICTT_xI4Tgc5R8fBieBTZSun_aA4Zvit-1sauJsmRQMzH07ObzcpROcbx_63w9YOXGY9LlHl1jjOa-7DqRQ$" target="_blank"><img src="https://images.printable.com/imagelibrary/Seller/3374/EWSDGTLLandingAssets_06092023085534_142/images/src/badge-google.png" alt="Get it on Google Play button" width="246" height="73"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="shape-pattern"></div>
  </div>
  <!-- End Block Hero 5 Code Snippet -->

<!-- Begin Paragraph Block Code Snippet -->
  <div class="block block-paragraph">
    <div class="wrapper">
        <div class="block-txt">
          <p style="margin-bottom: 0;">Zelle<sup class="reg">&reg;</sup> is a convenient way to send and receive money with friends, family and others you trust. Whether you’re splitting the cost of a meal, gift, or trip, Zelle<sup class="reg">&reg;</sup> makes it easy to pay your share. Over 100 million people are enrolled with Zelle<sup class="reg">&reg;</sup>, so you can send money to friends and family even if they don't bank at Fidelity Bank of Texas.<sup>*</sup></p>
        </div>
    </div>
  </div>
  <!-- End Paragraph Block Code Snippet -->

<!-- Begin 3-Column Block with Icons Code Snippet -->
  <div class="block block-multi-columns">
    <div class="wrapper">
     
        <div class="heading">
          <h2 class="heading-h2">Why use Zelle<sup class="reg">&reg;</sup>?</h2>
        
        
      </div>
      <div class="block-columns-wrapper three">
         <!-- Begin Third Benefit Choice HTML Variable -->
        <!-- Begin 1st Option --><div class="block-column"> <div class="svg-icon"> <?xml version="1.0" encoding="UTF-8"?><svg class="Layer_2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 77 85.75"><defs><style>.cls-1{fill:#6d1ed4;}</style></defs><g class="artwork"><path class="cls-1" d="m38.5,85.75c-.14,0-.29-.03-.42-.09C4.18,69.85.16,35.66,0,21.7c0-.46.31-.87.76-.98C18.82,16.24,32.7,4.92,37.83.26c.38-.35.96-.35,1.35,0,5.13,4.66,19,15.98,37.07,20.46.45.11.76.52.76.98-.15,13.96-4.16,48.14-38.08,63.95-.13.06-.28.09-.42.09ZM2.01,22.46c.29,13.98,4.61,46.06,36.49,61.18,31.88-15.13,36.2-47.2,36.49-61.18-17.39-4.52-30.86-15.12-36.49-20.12-5.63,5-19.1,15.6-36.49,20.12Z"/><path class="cls-1" d="m39.02,63.52c-.55,0-1-.45-1-1v-4.06c-3.83-.22-7.73-1.75-10.28-4.45-.38-.4-.36-1.03.04-1.41.4-.38,1.03-.36,1.41.04,3.97,4.2,12.03,5.15,16.27,1.93.68-.52,1.24-1.2,1.54-1.87.74-1.65.69-3.58-.12-5.17-.97-1.9-3.11-2.81-5.4-3.65-.9-.33-1.82-.63-2.74-.92-1.55-.49-3.15-1-4.67-1.7-3.27-1.54-4.93-4.07-4.82-7.32.14-3.95,2.61-5.49,4.75-6.4,1.25-.53,2.61-.83,4.01-.94v-3.35c0-.55.45-1,1-1s1,.45,1,1v3.32c3.03.12,5.99,1.03,7.97,2.32.46.3.59.92.29,1.38s-.92.59-1.38.29c-2.83-1.85-8.37-2.76-12.11-1.18-2.05.87-3.44,1.99-3.54,4.63-.09,2.45,1.11,4.23,3.66,5.43,1.41.64,2.95,1.13,4.44,1.61.95.3,1.89.61,2.82.95,2.57.94,5.19,2.08,6.49,4.61,1.09,2.12,1.15,4.7.17,6.9-.44.98-1.21,1.92-2.16,2.65-1.82,1.38-4.17,2.13-6.66,2.3v4.07c0,.55-.45,1-1,1Z"/></g></svg> </div> <div class="heading"> <h3 class="heading-h3">CONVENIENT</h3> </div> <div class="block-txt"> <p>Zelle<sup class="reg">&reg;</sup> is available in the FBOT Mobile App, so there&#39;s no need to download another app.</p> </div> </div> <div class="border-column"></div>
        <!-- End Third Benefit Choice HTML Variable -->

        <div class="block-column">
          <div class="svg-icon">
            <?xml version="1.0" encoding="UTF-8"?><svg class="Layer_2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 77 88.47"><defs><style>.cls-1{fill:#000000;}</style></defs><g class="artwork"><path class="cls-1" d="m41.04,88.47c-1.93,0-3.87-.15-5.81-.47-17.87-2.87-30.74-17.7-30.6-35.26,0-.55.45-.99,1-.99h0c.55,0,1,.46.99,1.01-.13,16.56,12.03,30.56,28.92,33.27,9.02,1.45,18.05-.7,25.42-6.06,7.37-5.36,12.21-13.28,13.62-22.31,2.91-18.64-9.88-36.23-28.5-39.22-9.03-1.45-18.05.7-25.42,6.06-7.37,5.36-12.21,13.28-13.62,22.3-.08.54-.59.92-1.14.83-.55-.08-.92-.6-.83-1.14,1.49-9.56,6.61-17.94,14.42-23.61s17.37-7.95,26.91-6.42c19.71,3.17,33.24,21.79,30.16,41.51-1.49,9.56-6.61,17.94-14.42,23.61-6.22,4.52-13.55,6.88-21.1,6.88Z"/><path class="cls-1" d="m10.17,58.72c-.27,0-.54-.11-.74-.32l-3.82-4.18-3.89,4.11c-.38.4-1.01.42-1.41.04-.4-.38-.42-1.01-.04-1.41l4.63-4.9c.19-.2.46-.35.73-.31.28,0,.54.12.73.32l4.55,4.97c.37.41.35,1.04-.06,1.41-.19.18-.43.26-.67.26Z"/><path class="cls-1" d="m71.98,27.42c-.3,0-.6-.13-.79-.39-2.59-3.38-5.74-6.21-9.35-8.41-.47-.29-.62-.9-.33-1.37s.9-.62,1.38-.33c3.82,2.34,7.15,5.33,9.89,8.9.34.44.25,1.07-.18,1.4-.18.14-.4.21-.61.21Z"/><path class="cls-1" d="m52.27,15.06c-.55,0-1-.45-1-1v-7.01c0-2.79-2.27-5.06-5.05-5.06h-10.81c-2.79,0-5.06,2.27-5.06,5.06v7.01c0,.55-.45,1-1,1s-1-.45-1-1v-7.01c0-3.89,3.17-7.06,7.06-7.06h10.81c3.89,0,7.05,3.17,7.05,7.06v7.01c0,.55-.45,1-1,1Z"/><path class="cls-1" d="m41.04,88.47c-1.93,0-3.87-.15-5.81-.47-17.87-2.87-30.74-17.7-30.6-35.26,0-.55.45-.99,1-.99h0c.55,0,1,.46.99,1.01-.13,16.56,12.03,30.56,28.92,33.27,9.02,1.45,18.05-.7,25.42-6.06,7.37-5.36,12.21-13.28,13.62-22.31,2.91-18.64-9.88-36.23-28.5-39.22-9.03-1.45-18.05.7-25.42,6.06-7.37,5.36-12.21,13.28-13.62,22.3-.08.54-.59.92-1.14.83-.55-.08-.92-.6-.83-1.14,1.49-9.56,6.61-17.94,14.42-23.61s17.37-7.95,26.91-6.42c19.71,3.17,33.24,21.79,30.16,41.51-1.49,9.56-6.61,17.94-14.42,23.61-6.22,4.52-13.55,6.88-21.1,6.88Z"/><path class="cls-1" d="m40.81,17.13c-.55,0-1-.45-1-1v-7.5c0-.55.45-1,1-1s1,.45,1,1v7.5c0,.55-.45,1-1,1Z"/><path class="cls-1" d="m40.82,73.11c-.55,0-1-.45-1-1v-4.06c-3.83-.22-7.73-1.75-10.29-4.45-.38-.4-.36-1.03.04-1.41.4-.38,1.03-.36,1.41.04,3.97,4.2,12.04,5.15,16.27,1.93.68-.52,1.24-1.2,1.54-1.87.74-1.65.69-3.58-.12-5.17-.97-1.9-3.11-2.81-5.4-3.65-.9-.33-1.82-.63-2.74-.92-1.55-.49-3.14-1.01-4.67-1.7-3.27-1.54-4.93-4.07-4.82-7.32.14-3.95,2.61-5.5,4.75-6.4,1.25-.53,2.62-.83,4.01-.94v-3.35c0-.55.45-1,1-1s1,.45,1,1v3.32c3.03.12,5.99,1.03,7.97,2.32.46.3.59.92.29,1.38-.3.46-.92.59-1.38.29-2.83-1.85-8.38-2.76-12.11-1.18-2.05.87-3.44,1.99-3.54,4.63-.09,2.45,1.11,4.23,3.66,5.43,1.41.64,2.95,1.13,4.44,1.61.95.3,1.89.61,2.82.95,2.57.94,5.19,2.08,6.49,4.61,1.09,2.12,1.15,4.7.17,6.9-.44.98-1.21,1.92-2.16,2.65-1.82,1.38-4.17,2.13-6.65,2.3v4.07c0,.55-.45,1-1,1Z"/></g></svg>
          </div>
          <div class="heading">
            <h3 class="heading-h3">FAST</h3>
          </div>
          <div class="block-txt">
            <p>Money goes straight into your account and is available to use in minutes.<sup>*</sup></p>
          </div>
        </div>
        <div class="border-column"></div>
   <div class="block-column third"> <div class="svg-icon"> <?xml version="1.0" encoding="UTF-8"?><svg class="Layer_2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 77 85.75"><defs><style>.cls-1{fill:#6d1ed4;}</style></defs><g class="artwork"><path class="cls-1" d="m38.5,85.75c-.14,0-.29-.03-.42-.09C4.18,69.85.16,35.66,0,21.7c0-.46.31-.87.76-.98C18.82,16.24,32.7,4.92,37.83.26c.38-.35.96-.35,1.35,0,5.13,4.66,19,15.98,37.07,20.46.45.11.76.52.76.98-.15,13.96-4.16,48.14-38.08,63.95-.13.06-.28.09-.42.09ZM2.01,22.46c.29,13.98,4.61,46.06,36.49,61.18,31.88-15.13,36.2-47.2,36.49-61.18-17.39-4.52-30.86-15.12-36.49-20.12-5.63,5-19.1,15.6-36.49,20.12Z"/><path class="cls-1" d="m39.02,63.52c-.55,0-1-.45-1-1v-4.06c-3.83-.22-7.73-1.75-10.28-4.45-.38-.4-.36-1.03.04-1.41.4-.38,1.03-.36,1.41.04,3.97,4.2,12.03,5.15,16.27,1.93.68-.52,1.24-1.2,1.54-1.87.74-1.65.69-3.58-.12-5.17-.97-1.9-3.11-2.81-5.4-3.65-.9-.33-1.82-.63-2.74-.92-1.55-.49-3.15-1-4.67-1.7-3.27-1.54-4.93-4.07-4.82-7.32.14-3.95,2.61-5.49,4.75-6.4,1.25-.53,2.61-.83,4.01-.94v-3.35c0-.55.45-1,1-1s1,.45,1,1v3.32c3.03.12,5.99,1.03,7.97,2.32.46.3.59.92.29,1.38s-.92.59-1.38.29c-2.83-1.85-8.37-2.76-12.11-1.18-2.05.87-3.44,1.99-3.54,4.63-.09,2.45,1.11,4.23,3.66,5.43,1.41.64,2.95,1.13,4.44,1.61.95.3,1.89.61,2.82.95,2.57.94,5.19,2.08,6.49,4.61,1.09,2.12,1.15,4.7.17,6.9-.44.98-1.21,1.92-2.16,2.65-1.82,1.38-4.17,2.13-6.66,2.3v4.07c0,.55-.45,1-1,1Z"/></g></svg> </div> <div class="heading"> <h3 class="heading-h3">PRIVATE</h3> </div> <div class="block-txt"> <p>All you need is an email address or U.S. mobile number. Your account information and activity stay private.</p> </div> </div>
        <div class="border-column"></div>
      </div>
    </div>
  </div>
  <!-- End 3-Column Block with Icons Code Snippet -->

 <!-- Begin Download Block 2 Code Snippet -->
  <div class="block block-download two">
    <div class="wrapper">
      <div class="download-two">
        <div class="heading">
          <h2 class="heading-h2">Make the switch <span class="keep-words-together">to Zelle<sup class="reg">&reg;</sup>.</span></h2>
        </div>
        <div class="content">
          <div class="block-txt">
            <p>Download the FBOT Mobile App to get started:</p>
          </div>
          <div class="badges">
            <div class="badge-btn apple">
              <a class="external" href="https://urldefense.com/v3/__https://apps.apple.com/us/app/fbot-mobile/id1244150751__;!!AI5hVGByxkJIiw!jLbICTT_xI4Tgc5R8fBieBTZSun_aA4Zvit-1sauJsmRQMzH07ObzcpROcbx_63w9YOXGY9LlHl1jjMgSSvIuQ$" target="_blank"><img src="https://images.printable.com/imagelibrary/Seller/3374/EWSDGTLLandingAssets_06092023085534_142/images/src/badge-apple.png" alt="Download on the App Store button" width="219" height="73"></a>
            </div>
            <div class="badge-btn google">
              <a class="external" href="https://urldefense.com/v3/__https://play.google.com/store/apps/details?id=com.mfoundry.mb.android.mb_111905340&amp;hl=en_US&amp;pli=1__;!!AI5hVGByxkJIiw!jLbICTT_xI4Tgc5R8fBieBTZSun_aA4Zvit-1sauJsmRQMzH07ObzcpROcbx_63w9YOXGY9LlHl1jjOa-7DqRQ$" target="_blank"><img src="https://images.printable.com/imagelibrary/Seller/3374/EWSDGTLLandingAssets_06092023085534_142/images/src/badge-google.png" alt="Get it on Google Play button" width="246" height="73"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End Download Block 2 Code Snippet -->


<!-- Begin 3-Step with Numbered Icons Block Code Snippet -->
<div class="block block-steps">
    <div class="wrapper">
      <div class="heading">
        <h2 class="heading-h2">Enroll with Zelle<sup class="reg">&reg;</sup> in 3 simple steps:</h2>
      </div>
       <div class="step-process number">
        <div class="step">
          <div class="circle-number">1</div>
          <div class="block-txt">
            <p>Log into the <span class="var-placeholder">FBOT Mobile App</span>.</p>
          </div>
        </div>
        <div class="icon-arrow-next"></div>
        <div class="step">
          <div class="circle-number">2</div>
          <div class="block-txt">
            <p><span class="var-placeholder">In the main menu, select "Transfer and Pay". Then "Send money with Zelle<sup>&#174;</sup>".</span></p>
          </div>
        </div>
        <div class="icon-arrow-next"></div>
        <div class="step">
          <div class="circle-number">3</div>
          <div class="block-txt">
            <p>Enroll your email address or U.S. mobile number.</p>
          </div>
        </div>
      </div>
<!-- Begin Paragraph Block Code Snippet -->
  <div class="block block-paragraph">
    <div class="wrapper" style="padding-bottom: 10px;">
        <div class="block-txt">
          <p style="margin-bottom: 0;">You’re ready to start sending and receiving money with Zelle<sup class="reg">&reg;</sup>. Zelle<sup class="reg">&reg;</sup> transactions show up in your checking account activity, so you can easily keep track of your money.
<br><br>
Next time you need to send money, use Zelle<sup class="reg">&reg;</sup>!</p>
        </div>
    </div>
  </div>
  <!-- End Paragraph Block Code Snippet -->
    </div>
  </div>
  <!-- End 3-Step with Numbered Icons Block Code Snippet -->


 
<!-- Begin FAQ Block no tabs Code Snippet -->
  <div class="block block-faq no-tabs">
    <div class="wrapper">
      <div class="heading">
        <h2 class="heading-h2">Frequently Asked Questions</h2>
      </div>
      <div id="Personal" class="faqs-tab-content">
        <div class="faq-content">
          <div class="faq-question">
            <h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_1" aria-expanded="false" tabindex="0" id="per_accordion_title_1" aria-selected="false" aria-label="How do I use Zelle®? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>How do I use Zelle<sup class="reg">&reg;</sup>?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_1" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_1">
<div tabindex="0">
            <p>You can send, request, or receive money with Zelle<sup class="reg">&reg;</sup>. To get started, log into the FBOT Mobile App&nbsp;or online banking. In the main menu, select "Transfer and Pay". Then "Send money with Zelle<sup>&#174;</sup>".</p>
            <p>To send money using Zelle<sup class="reg">&reg;</sup>, simply select someone from your mobile device's contacts (or add a trusted recipient's email address or U.S. mobile number), add the amount you'd like to send and an optional note, review, then hit "Send." The recipient will receive an email or text message notification via the method they used to enroll with Zelle<sup class="reg">&reg;</sup>. Money is available to your recipient in minutes if they are already enrolled with Zelle<sup class="reg">&reg;</sup>.</p>
            <p>To request money using Zelle<sup class="reg">&reg;</sup>, choose "Request," select the individual from whom you'd like to request money, enter the amount you'd like, include an optional note, review and hit "Request". If the person you are requesting money from is not yet enrolled with Zelle<sup class="reg">&reg;</sup>, you must use their email address to request money. If the person has enrolled their U.S. mobile number, then you can send the request using their U.S. mobile number.</p>
            <p>To receive money, just share your enrolled email address or U.S. mobile number with a friend and ask them to send you money with Zelle<sup class="reg">&reg;</sup>. If you have already enrolled with Zelle<sup class="reg">&reg;</sup>, you do not need to take any further action. The money will be sent directly into your Fidelity Bank of Texas account, typically within minutes.</p>
            <p>If someone sent you money with Zelle<sup class="reg">&reg;</sup> and you have not yet enrolled with Zelle<sup class="reg">&reg;</sup>, follow these steps:</p>
            <ol type="a">
              <li>Click on the link provided in the payment notification you received via email or text message.</li>
              <li>Select Fidelity Bank of Texas.</li>
              <li>Follow the instructions provided on the page to enroll and receive your payment. Pay attention to the email address or U.S. mobile number where you received the payment notification - you should enroll with Zelle<sup class="reg">&reg;</sup> using that email address or U.S. mobile number to ensure you receive your money.</li>
            </ol>
          </div>
        </div>
</div>
        <div class="faq-content">
          <div class="faq-question">
<h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_2" aria-expanded="false" tabindex="0" id="per_accordion_title_2" aria-selected="false" aria-label="Is my information secure? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>Is my information secure?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_2" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_2">
<div tabindex="0">
            <p>Keeping your money and information secure is a top priority for Fidelity Bank of Texas. When you use Zelle<sup class="reg">&reg;</sup> within our mobile app&nbsp;or online banking, your information is protected with the same technology we use to keep your Fidelity Bank of Texas account safe.</p>
          </div>
        </div>
</div>

        <div class="faq-content">
          <div class="faq-question">
                        <h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_3" aria-expanded="false" tabindex="0" id="per_accordion_title_3" aria-selected="false" aria-label="Who can I send money to with Zelle®? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>Who can I send money to with Zelle<sup class="reg">&reg;</sup>?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_3" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_3">
<div tabindex="0">
            <p>Zelle<sup class="reg">&reg;</sup> is a great way to send money to family, friends, and people you are familiar with such as your personal trainer, babysitter or neighbor.<sup>*</sup></p>
            <p>Since money is sent directly from your Fidelity Bank of Texas account to another person's bank account within minutes<sup>*</sup>, Zelle<sup class="reg">&reg;</sup> should only be used to send money to friends, family and others you trust.</p>
            <p>If you don't know the person or aren't sure you will get what you paid for (for example, items bought from an online bidding or sales site), you should not use Zelle<sup class="reg">&reg;</sup>. These transactions are potentially high risk (just like sending cash to a person you don't know is high risk).</p>
          </div>
        </div>
        </div>


        <div class="faq-content">
          <div class="faq-question">
            <h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_4" aria-expanded="false" tabindex="0" id="per_accordion_title_4" aria-selected="false" aria-label="Can I pay a small business with Zelle®? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>Can I pay a small business with Zelle<sup class="reg">&reg;</sup>?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_4" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_4">
<div tabindex="0">
            <p>Some small businesses are able to receive payments with Zelle<sup class="reg">&reg;</sup>. Ask your favorite small business if they accept payments with Zelle<sup class="reg">&reg;</sup>. If they do, you can pay them directly from the FBOT Mobile App&nbsp;or online banking using just their email address or U.S. mobile number.</p>
          </div>
        </div>
</div>

  <div class="faq-content">
          <div class="faq-question">
            <h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_5" aria-expanded="false" tabindex="0" id="per_accordion_title_5" aria-selected="false" aria-label="Does Fidelity Bank of Texas or Zelle® offer purchase protection? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>Does Fidelity Bank of Texas or Zelle<sup class="reg">&reg;</sup> offer purchase protection?</span></button>
</h3>          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_5" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_5">
<div tabindex="0">
            <p>Neither Fidelity Bank of Texas nor Zelle<sup class="reg">&reg;</sup> offers purchase protection for payments made with Zelle<sup class="reg">&reg;</sup> - for example, if you do not receive the item you paid for, or the item is not as described or as you expected. Only send money to people and small businesses you trust and always ensure you've used the correct email address or U.S. mobile number when sending money.</p>
          </div>
        </div>
        </div>


        <div class="faq-content">
          <div class="faq-question">
                        <h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_6" aria-expanded="false" tabindex="0" id="per_accordion_title_6" aria-selected="false" aria-label="I believe I’ve been a victim of a scam. Who should I contact?®? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>I believe I’ve been a victim of a scam. Who should I contact?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_6" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_6">
<div tabindex="0">
            <p>Please contact our customer support team at 254-755-6555. Qualifying imposter scams may be eligible for reimbursement.</p>
          </div>
        </div>
        </div>



        <div class="faq-content">
          <div class="faq-question">
<h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_7" aria-expanded="false" tabindex="0" id="per_accordion_title_7" aria-selected="false" aria-label="Can I use Zelle® internationally? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>Can I use Zelle<sup class="reg">&reg;</sup> internationally?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_7" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_7">
<div tabindex="0">
            <p>In order to use Zelle<sup class="reg">&reg;</sup>, the sender and recipient's bank or credit union accounts must be based in the U.S.</p>
          </div>
        </div>
          </div>

        <div class="faq-content">
          <div class="faq-question">
            <h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_8" aria-expanded="false" tabindex="0" id="per_accordion_title_8" aria-selected="false" aria-label="Can I reverse or cancel a payment? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>Can I reverse or cancel a payment?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_8" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_8">
<div tabindex="0">
    <p>No, Zelle<sup class="reg">&reg;</sup> payments cannot be reversed.</p>
            <p>You can only cancel a payment if the person you sent money to hasn't yet enrolled with Zelle<sup class="reg">&reg;</sup>. To check whether the payment is still pending because the recipient hasn't yet enrolled, you can go to your activity page, choose the payment you want to cancel, and then select "Cancel This Payment". If you do not see this option available, please contact our customer support team at 254-755-6555 for assistance with canceling the pending payment.</p>
            <p>If the person you sent money to has already enrolled with Zelle<sup class="reg">&reg;</sup> through their bank or credit union’s mobile app&nbsp;or online banking, the money is sent directly to their bank account and cannot be canceled. This is why it's important to only send money to people you know and trust, and always ensure you've used the correct email address or U.S. mobile number when sending money.</p>
            <p>If you sent money to the wrong person, please immediately call our customer support team at 254-755-6555 to determine what options are available.</p>
          </div>
        </div>
</div>
        <div class="faq-content">
          <div class="faq-question">
<h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_9" aria-expanded="false" tabindex="0" id="per_accordion_title_9" aria-selected="false" aria-label="Are there any fees to send money using Zelle®? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>Are there any fees to send money using Zelle<sup class="reg">&reg;</sup>?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_9" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_9">
<div tabindex="0">
            <p>No, Fidelity Bank of Texas does not charge any fees to use Zelle&#174; in our mobile app.</p>
            <p>Your mobile carrier's messaging and data rates may apply. </p>
          </div>
        </div>
</div>
        <div class="faq-content">
          <div class="faq-question">
            <h3 class="heading-h3">
<button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_10" aria-expanded="false" tabindex="0" id="per_accordion_title_10" aria-selected="false" aria-label="What if I want to send money to someone whose bank or credit union doesn't offer Zelle®? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>What if I want to send money to someone whose bank or credit union doesn't offer Zelle<sup class="reg">&reg;</sup>?</span></button>
</h3>
          </div>
          <div class="block-txt faq-answer" id="per_accordion_content_10" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_10">
<div tabindex="0">
            <p>As of March 31, 2025, all users must be enrolled through one of the more than 2,200 banks and credit unions that offer Zelle<sup class="reg">&reg;</sup> in order to send and receive money. The list of participating financial institutions is always growing. You can find the updated list of participating banks and credit unions live with Zelle<sup class="reg">&reg;</sup> at <a style="color: #000000;" href="https://urldefense.com/v3/__https://www.zellepay.com/get-started__;!!AI5hVGByxkJIiw!jLbICTT_xI4Tgc5R8fBieBTZSun_aA4Zvit-1sauJsmRQMzH07ObzcpROcbx_63w9YOXGY9LlHl1jjNAMdwrfw$" target="_blank">Zellepay.com</a>. If their bank or credit union is not listed, we recommend you use another payment method at this time.</p>
            
</div>
</div>
</div>


 <!-- Begin Question for showing/hiding 1 of 2 questions/answers -->
 <div class="faq-content"> <div class="faq-question"><h3 class="heading-h3"><button class="heading-h3 accordion_trigger" aria-controls="per_accordion_content_11" aria-expanded="false" tabindex="0" id="per_accordion_title_11" aria-selected="false" aria-label="How do I use a Zelle&#174; QR code? Click to expand."><svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path class="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg><span>How do I use a Zelle<sup class="reg">&reg;</sup> QR code?</span></button></h3> </div> <div class="block-txt faq-answer" id="per_accordion_content_11" role="region" aria-hidden="true" aria-labelledby="per_accordion_title_11"><div tabindex="0"> <p>Zelle<sup class="reg">&reg;</sup> QR code provides peace of mind knowing you can send and receive money, without typing or providing an email address or U.S. mobile number.</p> <p>To locate your Zelle<sup class="reg">&reg;</sup> QR code, log into the FBOT Mobile App. In the main menu, select "Transfer and Pay". Then "Send money with Zelle<sup>&#174;</sup>". Click "Send," then click on the QR code icon displayed at the top of the "Select Recipient" screen. Navigate to "My Code." From here you can view and use the print or share icons to text or email your Zelle<sup class="reg">&reg;</sup> QR code.</p> <p>To send money, log into the FBOT Mobile App. In the main menu, select "Transfer and Pay". Then "Send money with Zelle<sup>&#174;</sup>". Click "Send," then click on the QR code icon displayed at the top of the "Select Recipient" screen. Once you allow access to your camera, simply point your camera at the recipient's Zelle&#174; QR code, enter the amount, hit "Send," and the money is on the way! When sending money to someone new, it's always important to confirm the recipient is correct by reviewing the displayed name before sending money. </p> </div> </div></div>


<div class="show-btn block-txt">
    <button type="button" tabindex="0" onclick="showHidePersonal()" id="btn-show-personal">
      Show more<svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path id="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg>
    </button>
  </div>
  <div class="show-btn show-less block-txt">
    <button type="button" tabindex="0" onclick="showHidePersonal()" id="btn-show-less-personal">
      Show less<svg class="svg-arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="7.798" viewBox="0 0 14 7.798" preserveAspectRatio="xMaxYMax meet"><path id="Union_14" data-name="Union 14" d="M5.8,6,0,0,5.8,6,0,12Z" transform="translate(13 1) rotate(90)" fill="#000000" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"/></svg>
    </button>
  </div>
  
</div>
</div>
</div>
<!-- End FAQ Block no tabs Code Snippet -->




 <!-- Begin Footer 2 Block Code Snippet -->
  <div class="block block-footer two">
    <div class="wrapper">
      <div class="logos-badges">
        <div class="logos">
          <img src="https://images.printable.com/imagelibrary/Seller/22953/p1_39875232-4af4-4661-97a8-a38c13d4b91d/images/5280206/src/Fidelity%20-%20Zelle%20-%20Landscape%20Logo_4b2e469d-e4e4-4e7b-876c-9564e7a89d40.png" alt="Fidelity Bank of Texas" height="30" style="max-height: 30px;">
            <img src="https://images.printable.com/imagelibrary/Seller/3374/EarlyWarningHTMLImages_12062017133825_333/images/src/logo_zelle_purple_wPipe_30h.png" alt="Zelle Logo" width="102" height="30" style="max-height: 30px;">
        </div>
      </div>
      <div class="block-txt">
        <p><sup>*</sup> To send or receive money with Zelle<sup class="reg">&reg;</sup>, both parties must have an eligible checking or savings account. Transactions between enrolled users typically occur in minutes. </p>
        <p></p>
        <p>Zelle<sup class="reg">&reg;</sup> and the Zelle<sup class="reg">&reg;</sup> related marks are wholly owned by Early Warning Services, LLC and are used herein under license.</p>
      </div>
    </div>
  </div>
  <!-- End Footer 2 Block Code Snippet -->


  <script src="https://files.marcomcentral.app.pti.com/earlywarning/marcom/products/html/landings/803/js/faqs.js"></script>