<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>

<div class="standard_container">
	<div runat="server" id="ContentPane" class="Content"></div>
</div>
