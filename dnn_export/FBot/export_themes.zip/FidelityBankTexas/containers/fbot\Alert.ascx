<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>

<div class="alert alert-danger alert-dismissible fade show" role="alert" id="alertpane">
  <div class="Content" runat="server" id="ContentPane"> </div>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
