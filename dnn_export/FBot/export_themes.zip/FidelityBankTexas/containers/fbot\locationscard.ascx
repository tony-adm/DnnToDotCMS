<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>
<%@ Register TagPrefix="dnn" TagName="ICON" Src="~/Admin/Containers/Icon.ascx" %>
<%@ Register TagPrefix="dnn" TagName="TITLE" Src="~/Admin/Containers/Title.ascx" %>
<%@ Register TagPrefix="dnn" TagName="VISIBILITY" Src="~/Admin/Containers/Visibility.ascx" %>

<div class="locations-card">
  <div class="Account-card">
    <div class="card">
      <div class="card-header">
        <dnn:Icon runat="server" id="dnnIcon" loading="lazy" style="width: 100%" />
     
        <h3 class="card-title">
          <dnn:Title runat="server" id="dnnTitle" />
        </h3>
		   </div>
      <div class="card-body">
        <div class="card-text" runat="server" id="ContentPane"></div>
      </div>
    </div>
  </div>
</div>
