<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>
<%@ Register TagPrefix="dnn" TagName="ICON" Src="~/Admin/Containers/Icon.ascx" %>
<%@ Register TagPrefix="dnn" TagName="TITLE" Src="~/Admin/Containers/Title.ascx" %>
<%@ Register TagPrefix="dnn" TagName="VISIBILITY" Src="~/Admin/Containers/Visibility.ascx" %>

<div  class="hp-card-loc d-flex justify-content-center">
  <div class="card" style="width: 30rem;">
    <div class="card-header">
      <dnn:Icon runat="server" id="dnnIcon" loading="lazy" style="width: 100%" />
    </div>
    <div class="card-body">
      <h5 class="card-title">
        <dnn:Title runat="server" id="dnnTitle" />
      </h5>
      <div class="card-text" runat="server" id="ContentPane"></div>
    </div>
  </div>
</div>

