<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>

<div class="standard_container">
    <div runat="server" id="ContentPane" class="Content" style="display: none;"></div>
</div>


<script src="https://www.fws-weblink.com/api/ContactApi/Script" type="text/javascript" crossorigin="anonymous"></script>

  <div class="container py-4" data-action="true">
  <input id="bankname" name="BankName" type="hidden" value="Brighton Bank" />
  <input id="Formname" name="FormName" type="hidden" value="Contact" />

  <form aria-label="Contact Form">
    <div class="row mb-3">
      <div class="col-md-6">
        <label for="first_name" class="form-label">
          <strong>First Name</strong> <abbr title="required">*</abbr>
        </label>
        <input type="text" id="first_name" name="first_name" class="form-control" required aria-required="true" />
      </div>
      <div class="col-md-6">
        <label for="last_name" class="form-label">
          <strong>Last Name</strong> <abbr title="required">*</abbr>
        </label>
        <input type="text" id="last_name" name="last_name" class="form-control" required aria-required="true" />
      </div>
    </div>

    <div class="row mb-3">
      <div class="col-md-6">
        <label for="telephone" class="form-label"><strong>Telephone</strong></label>
        <input type="tel" id="telephone" name="telephone" class="form-control" />
      </div>
      <div class="col-md-6">
  <label for="email" class="form-label">
    <strong>Email</strong> <abbr title="required">*</abbr>
  </label>
  <input
    type="email"
    id="email"
    name="email"
    class="form-control"
    pattern="[a-zA-Z0-9!#$%&'*+/=?^_`{|}~.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*"
    required
    aria-required="true"
    aria-describedby="emailHelp"
  />
  
</div>
    </div>

    <div class="mb-3">
      <label for="address" class="form-label"><strong>Address</strong></label>
      <input type="text" id="address" name="address" class="form-control" />
    </div>

    <div class="row mb-3">
      <div class="col-md-4">
        <label for="city" class="form-label"><strong>City</strong></label>
        <input type="text" id="city" name="city" class="form-control" />
      </div>
      <div class="col-md-4">
        <label for="state" class="form-label"><strong>State</strong></label>
        <input type="text" id="state" name="state" class="form-control" />
      </div>
      <div class="col-md-4">
        <label for="zip" class="form-label"><strong>Zip Code</strong></label>
        <input type="text" id="zip" name="zip" class="form-control" />
      </div>
    </div>

    <div class="mb-3">
      <label for="comments" class="form-label">
        <strong>Comments</strong> <abbr title="required">*</abbr>
      </label>
      <textarea id="comments" name="comments" class="form-control" rows="5" required aria-required="true"></textarea>
    </div>

   
      <div style="text-align: left;">
                    <img style="border: 2px solid black;" id="imgCaptcha" alt="" data-name="imgCaptcha" /><br />
                    <a onclick="RefreshAllImages()" href="javascript:void(0)">Change Image</a><br />
                </div>
                <div style="text-align: left; width: 320px;">
                    <label for="captchacode">*Type the characters from the image above<em>*</em></label>
                    <input class="form-control" type="text" id="captchacode" name="captchacode" autocomplete="off" />
                    <div class="invalid-feedback">
                        Be sure captcha digits are correct.
                    </div>
                </div>
    </div>

    <div class="mb-3">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </form>
</div>
