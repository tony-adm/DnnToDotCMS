<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>
<%@ Register TagPrefix="dnn" TagName="ICON" Src="~/Admin/Containers/Icon.ascx" %>
<%@ Register TagPrefix="dnn" TagName="TITLE" Src="~/Admin/Containers/Title.ascx" %>

<div id="innerBanner">
  <dnn:Icon runat="server" id="dnnIcon" style="width=100%" />
</div>
<div class="inner">
  <div runat="server" id="ContentPane" class="Content" style="display: none"></div>
</div>
<style>
 
#dnn_BannerPaneInner img
  {
    
    width: 100%
}
	
</style>
