<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>
<%@ Register TagPrefix="dnn" TagName="ICON" Src="~/Admin/Containers/Icon.ascx" %>
<%@ Register TagPrefix="dnn" TagName="TITLE" Src="~/Admin/Containers/Title.ascx" %>

<div class="dropdown">
  <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">
    Login
  </button>
  <div class="dropdown-menu"><iframe src="/Portals/FidelityBankTexas/Containers/FBOT/login.html" style="width:248px; height:250px;" title="Online Banking"></iframe></div>

</div>
	
	
	<div class="standard_container">
	<div runat="server" id="ContentPane" class="Content" style="display: none"></div>
</div>


