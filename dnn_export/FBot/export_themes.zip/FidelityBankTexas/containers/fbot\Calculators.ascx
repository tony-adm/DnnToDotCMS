<%@ Control Language="vb" Codebehind="~/admin/Containers/container.vb" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>

<!--Begin Calculators Script-->

<!--Begin Calculators Content-->
<div class="cTimeValue">
    <script type="text/javascript">
 // Developers:  If you should have any questions or concerns 
 //              regarding the use of this script, please call 
 //              TimeValue Software Support at 800-426-4741
TEMPLATE_ID = "WWW.FBOT.COM_1";
HIDEFORMTAG = "TRUE";
 PASSTHROUGH = "HIDEFORMTAG=TRUE";
 if (document.location.href.substring(0,5) == "https") { URL = "https://"; } else { URL = "http://";}
 URL += "www.TimeValueCalculators.com/timevaluecalculators/includes/calculators_script.js";
 scriptTag = 'SCRIPT ';
 languageAttr = 'LANGUAGE="JavaScript" ';
 srcAttr = 'SR' + 'C="' + URL + '" '; //split for DNN
 typeAttr = 'TYPE="text/javascript" ';
 document.write('<' + scriptTag + languageAttr + srcAttr + '></' + scriptTag + '>');
</script>
</div>
<!--End Calculators Content-->

<script language="JavaScript" type="text/javascript">
//<!--
function SiteMigrationAlert(TVSURL)
{
var Notice = "You are leaving the First Savings Bank of Danville's website and linking to a third party site. Please be advised that you will then link to a website hosted by another party, where you will no longer be subject to, or under the protection of, the privacy and security policies of First Savings Bank of Danville. We recommend that you review and evaluate the privacy and security policies of the site that you are entering. The First Savings Bank of Danville assumes no liability for the content, information, security, policies or transactions provided by these other sites. \n\n Are you sure you want to continue?";
if (confirm(Notice)) {window.open(TVSURL);}
else {return false;}
}
//-->
</script>


<!--End Calculators Script-->

<style>

#COMPUTE {
    color: #fff!important;
    font-family: 'verdana' , 'arial' , 'helvetica';
    font-size: 1em;
    font-weight: normal;
    text-decoration: none;
    background-color: #6c3473!important;
    background-image:none!important;
    background-repeat: repeat-x;
    width: 120px;
    height: 45px;
    display: block;
    margin: 0;
    padding: 2px;
    border: 1px solid #6c3473!important;
}

h3 {color:#333!important;}
.radio+.radio, .checkbox+.checkbox {margin-top: none!important;}
.radio, .checkbox {display: inline!important;}
input[type="radio"], input[type="checkbox"] {margin: 4px!important;}
.TextInput {width: auto!important;}
.Summary, .Footnote {padding: 10px;}
.cTimeValue label {margin-right: 5px;}
.InputTable p {margin: 5px;}

.Summary {color: #900!important;font-size: 1.4em;}

input, button, select, textarea {line-height: auto!important;}



</style>