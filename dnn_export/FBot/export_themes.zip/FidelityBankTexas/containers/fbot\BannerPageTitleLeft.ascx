<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>
<%@ Register TagPrefix="dnn" TagName="ICON" Src="~/Admin/Containers/Icon.ascx" %>
<%@ Register TagPrefix="dnn" TagName="TITLE" Src="~/Admin/Containers/Title.ascx" %>

<!-- Banner Container -->
<div id="innerBanner" class="banner-container">
  <dnn:Icon runat="server" id="dnnIcon" style="width:100%;" />
  <h1 class="overlay-title">
    <dnn:TITLE runat="server" id="dnnTITLE" CssClass="TitleH1" />
  </h1>
</div>

<!-- Content Pane -->
<div class="inner">
  <div runat="server" id="ContentPane" class="Content" style="display: none;"></div>
</div>

<!-- Styles -->
<style>
  .banner-container {
    position: relative;
    width: 100%;
  }

  .overlay-title {
    position: absolute;
    top: 20px;
    left: 20px;
    background-color: rgba(0, 94, 184, 0.85); /* Semi-transparent blue */
    color: white;
    padding: 1em 1.5em;
    border-top-left-radius: 15px;
    border-top-right-radius: 15px;
    z-index: 10;
    font-size: 2em;
    max-width: 90%;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
    line-height: 1.2;
  }

  @media (max-width: 600px) {
    .overlay-title {
      font-size: 1.5em;
      padding: 0.75em 1em;
      left: 10px;
      right: 10px;
      max-width: calc(100% - 20px);
    }
  }

  #dnn_BannerPaneInner img,
  .banner-container img {
    width: 100%;
    height: auto;
    display: block;
  }
</style>
