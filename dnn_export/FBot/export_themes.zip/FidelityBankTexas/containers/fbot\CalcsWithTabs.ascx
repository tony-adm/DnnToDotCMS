<%@ Control Language="C#" AutoEventWireup="false" Explicit="True" Inherits="DotNetNuke.UI.Containers.Container" %>
<%@ Register TagPrefix="dnn" TagName="TITLE" Src="~/Admin/Containers/Title.ascx" %>

<style> 
 
/* ---- usually in skin, here for reference if you want them ---- */
#tvcTabsDiv { display: block; float: left; width: 100%; position: relative; left: 15px; z-index: 1; } 
button.tvcTab { position: relative; border-collapse: collapse; border-style: solid; border-color: #000000; padding: 3px 1em 2px 1em; margin-right: 3px; font-family: arial; text-decoration: none; float: none; color: white; background: #623e7c; -webkit-border-radius: 5px 5px 0 0; -moz-border-radius: 5px 5px 0 0; border-radius: 5px 5px 0 0; } 
@media screen and (max-width: 576px) { button.tvcTab { padding: 1px; margin-right: 1px; } 
 }
button.tvcTab:hover { background: white; color: black; } 
button.tvcSelectedTab { position: relative; padding-top: 6px; margin-top: 1px; color: black; border-top: solid 3px #005eb8; border-bottom: solid 1px white; background: white; -webkit-border-radius: 5px 5px 0 0; -moz-border-radius: 5px 5px 0 0; border-radius: 5px 5px 0 0; } 
@media screen and (max-width: 576px) { button.tvcSelectedTab { padding-top: 2px; } 
 }
.cTimeValue .panel { position: relative; border: solid 1px #005eb8; background-color: white; padding: 5px; height: auto; overflow: auto; display: none; z-index: 0; top: -1px; -webkit-border-radius: 8px; -moz-border-radius: 8px; border-radius: 8px; margin-bottom:20px; } 
.cTimeValue .selectedPanel { display: block; padding: 2%; } 
.cTimeValue H2 { font-size: 2em !important; } 
.cTimeValue H3 { font-size: 1.75em !important; } 
.cTimeValue li { margin-bottom: 5px; margin-left: 20px; } 
.cTimeValue .TextInput, .cTimeValue .tvcInputPClass, .InputContainer select { font-size: 1em !important; } 
.InputContainer label { font-size: 1em !important; } 
#tvcAllFieldsRequiredId { color: #ff0000; } 
input.tvcPercentOrDollarInputClass, input.tvcMonthsOrYearsInputClass, input.tvcPaymentOrTermInputClass { display: inline-block; width: 100% !important; font-size: 1em !important; } 
#COMPUTE { /* made the compute button match BS4 btn-primary */
 color: #fff !important; font-family: "Lato", sans-serif; font-size: .9em !important; font-weight: 700; text-decoration: none; background-color: #005eb8 !important; width: auto !important; height: auto !important; display: block; margin: 10px!important; padding: .375rem 1.75rem !important; border-radius: .25em !important; border: 1px solid #005eb8 !important; }
#COMPUTE:hover { background-color: #581527 !important; border-color: #581527 !important; text-decoration: underline !important; }   
 
</style>    
    
<script language="JavaScript" type="text/javascript">
function SiteMigrationAlert(TVSURL)
{
 var Notice = "This website provides these links as a convenience. ";
 Notice += "This website has no control over the linked websites or the content therein. ";
 Notice += "As such, This website has no liability arising out of linking to these websites ";
 Notice += "and the existence of such links does not constitute endorsement by this website.";

 if (confirm(Notice)) {window.open(TVSURL);}
 else {return false;}
}
</script>

<script type="text/javascript">
    var tvcTabs = new Array('Personal', 'Investment', 'Retirement', 'Lease', 'Home');
    var tvcTabTitles = new Array('Personal', 'Investment', 'Retirement', 'Lease', 'Home');
    var tvcSelectedTab = null;
</script>

<link rel="StyleSheet" type="text/css" href="https://www.TimeValueCalculators.com/timevaluecalculators/Includes/tvcDefaultStyles.css" />
<script language="JavaScript" src="https://www.TimeValueCalculators.com/timevaluecalculators/Includes/tvcClientSideFunctions.js" type="text/javascript"></script>
<div id="tvcMainCalculatorDivId" class="cTimeValue" style="margin-top: 2em;">
	<script type="text/javascript" language="JavaScript">
		TEMPLATE_ID = "www.gdwbank.com_3";
		CALCULATORID = "";
		PASSTHROUGH = "";

		var tvcScriptElement = document.createElement('script');
		var tvcCalculatorHtml = "";
		var tvcHttp;
		if (document.location.href.substring(0, 5) == "https") { tvcHttp = "https://"; } else { tvcHttp = "http://"; }
		tvcScriptElement.src = tvcHttp + "www.TimeValueCalculators.com/timevaluecalculators/Calculator2.aspx?version=" + Math.random() + "&" + createQueryString();
		tvcScriptElement.onload = tvcOnceLoaded;
		document.getElementById('tvcMainCalculatorDivId').appendChild(tvcScriptElement);
	</script>
</div>

    <script language="JavaScript" type="text/javascript">
QS = unescape(document.location.search);
if (QS.indexOf("CALCULATORID") > 0)
{
//Go back one step back in history
document.write('<a href="javascript:history.back();">&lt;&lt; Return to Calculator List</a><br/>');
}
</script>